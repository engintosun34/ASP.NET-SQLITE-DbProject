﻿using Microsoft.EntityFrameworkCore;

namespace DbProject.Models
{
    public class RepositoryContext : DbContext
    {
        public DbSet<Product> Products { get; set; }
        public RepositoryContext(DbContextOptions<RepositoryContext> options)
            : base(options)
        {
            
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Product>()
                .HasData(

                new Product() { ProductId = 1, ProductName = "Sabun", Price = 1700 },
                new Product() { ProductId = 2, ProductName = "Kalem", Price = 1200 },
                new Product() { ProductId = 3, ProductName = "Kitap", Price = 1300 },
                new Product() { ProductId = 4, ProductName = "Silgi", Price = 1600 },
                new Product() { ProductId = 5, ProductName = "Yaprak sarması", Price = 100 }




                );

        }
    }

}
